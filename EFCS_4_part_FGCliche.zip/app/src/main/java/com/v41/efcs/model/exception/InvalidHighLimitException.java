package com.v41.efcs.model.exception;

public class InvalidHighLimitException extends Exception {
  public InvalidHighLimitException(String message) {
    super(message);
  }
}
