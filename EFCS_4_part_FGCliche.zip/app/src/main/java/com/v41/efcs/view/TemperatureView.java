package com.v41.efcs.view;

public interface TemperatureView {
  void setLimitsEnabled(boolean enabled);
  boolean isLimitsEnabled();
}
