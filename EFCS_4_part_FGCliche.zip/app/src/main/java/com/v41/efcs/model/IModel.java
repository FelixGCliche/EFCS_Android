package com.v41.efcs.model;

public interface IModel {
}
