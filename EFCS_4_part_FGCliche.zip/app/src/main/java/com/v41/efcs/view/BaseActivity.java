package com.v41.efcs.view;

import android.content.Intent;
import android.os.Parcelable;

import androidx.appcompat.app.AppCompatActivity;

import com.v41.efcs.R;
import com.v41.efcs.model.entity.SensorData;

public class BaseActivity extends AppCompatActivity {

  /**
   * Retourne le nombre d'entrées d'un senseur
   * @param sensorData Senseur à vérifier
   * @return Nombre d'entrées du senseur
   */
  protected int getSensorDataCount(SensorData sensorData) {
    return sensorData.getValues().length;
  }

  /**
   * Retourne un extra de type Parcelable associé le nom en paramètre
   * @param name nom de l'extra
   * @return Parcelable associé au nom s'il existe, sinon null
   */
  protected Parcelable getIntentParcelable(String name) {
    if (getIntent().hasExtra(name))
      return getIntent().getParcelableExtra(name);
    else
      return null;

  }
}
