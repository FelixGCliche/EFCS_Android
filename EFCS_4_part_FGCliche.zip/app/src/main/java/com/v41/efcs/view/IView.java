package com.v41.efcs.view;

public interface IView {
  /**
   * Initialisation des propriétés de la vue
   */
  void init();

  /**
   * Affichage des mises à jour de la vue
   */
  void show();

  /**
   * Gestion des mises à jour de la vue
   */
  void update();
}
