package com.v41.efcs.model.entity;

public class PreferencesData {

  private long id;
  private int keepPreferences;
  private double tempLowLimit;
  private double tempHighLimit;

  private double[] humidityHighLimits;

  public PreferencesData() {
  }

  public PreferencesData(long id, int keepPreferences, double tempLowLimit, double tempHighLimit, double[] humidityHighLimits) {
    this.id = id;
    this.keepPreferences = keepPreferences;
    this.tempLowLimit = tempLowLimit;
    this.tempHighLimit = tempHighLimit;
    this.humidityHighLimits = humidityHighLimits;
  }

  /**
   * Retourne la liste de string nécéssaire à une insertion via un repository
   * @return liste de string
   */
  public String[] getTransactionableData() {
    return new String[] {
            String.valueOf(keepPreferences),
            String.valueOf(tempLowLimit),
            String.valueOf(tempHighLimit),
            String.valueOf(humidityHighLimits[0]),
            String.valueOf(humidityHighLimits[1]),
            String.valueOf(humidityHighLimits[2]),
            String.valueOf(humidityHighLimits[3])
    };
  }

  /**
   * Retourne la liste de string nécéssaire à une mise à jour via un repository
   * @return
   */
  public String[] getUpdateData() {
    return new String[] {
            String.valueOf(keepPreferences),
            String.valueOf(tempLowLimit),
            String.valueOf(tempHighLimit),
            String.valueOf(humidityHighLimits[0]),
            String.valueOf(humidityHighLimits[1]),
            String.valueOf(humidityHighLimits[2]),
            String.valueOf(humidityHighLimits[3]),
            String.valueOf(id)
    };
  }

  public long getId() {
    return id;
  }

  public int getKeepPreferences() {
    return keepPreferences;
  }

  public double getTempLowLimit() {
    return tempLowLimit;
  }

  public double getTempHighLimit() {
    return tempHighLimit;
  }

  public double[] getHumidityHighLimits() {
    return humidityHighLimits;
  }
}
