package com.v41.efcs.view;

public interface HumidityView {
  void setApplyButtonEnabled(boolean enabled);
  boolean isApplyButtonEnabled();
}
